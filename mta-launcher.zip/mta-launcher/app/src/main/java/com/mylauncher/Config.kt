package com.mylauncher

/** Всё, что нужно поменять под свой проект, находится здесь. */
object Config {
    /** Прямая ссылка на ваш мобильный .zip */
    const val ZIP_URL = "https://github.com/t41121878-rgb/Mtalite/releases/download/v1/game.zip"

    /** Пакет Android-клиента, например "com.example.mtaclient". */
    const val CLIENT_PACKAGE = "com.litmobile.game"

    const val DEFAULT_IP = "188.127.241.74"
    const val DEFAULT_PORT = 4380

    /** Ссылка, которая возвращает число игроков онлайн (просто число текстом). Пусто = прочерк. */
    const val ONLINE_URL = ""
}
