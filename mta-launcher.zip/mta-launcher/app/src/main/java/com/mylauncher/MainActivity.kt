package com.mylauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var nick: EditText
    private lateinit var online: TextView
    private lateinit var subtitle: TextView
    private lateinit var progress: ProgressBar
    private var busy = false

    private val gameDir get() = File(getExternalFilesDir(null), "game")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)

        nick = findViewById(R.id.nick)
        online = findViewById(R.id.online)
        subtitle = findViewById(R.id.subtitle)
        progress = findViewById(R.id.progress)

        nick.setText(prefs.getString("nick", ""))
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnPlay).setOnClickListener { onPlay() }
    }

    override fun onResume() {
        super.onResume()
        refreshOnline()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacksAndMessages(null)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun refreshOnline() {
        if (Config.ONLINE_URL.isBlank()) {
            online.text = "—"
            return
        }
        Thread {
            val text = try {
                val c = URL(Config.ONLINE_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.inputStream.bufferedReader().use { it.readText() }.trim().toIntOrNull()?.toString() ?: "—"
            } catch (e: Exception) {
                "—"
            }
            ui.post { online.text = text }
        }.start()
        ui.postDelayed({ refreshOnline() }, 30_000)
    }

    private fun showSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        fun field(hintText: String, value: String, type: Int): EditText =
            EditText(this).apply {
                hint = hintText
                setText(value)
                inputType = type
                box.addView(this)
            }

        val ip = field("IP сервера", prefs.getString("ip", Config.DEFAULT_IP) ?: "", InputType.TYPE_CLASS_TEXT)
        val port = field("Порт", prefs.getInt("port", Config.DEFAULT_PORT).toString(), InputType.TYPE_CLASS_NUMBER)
        val pass = field(
            "Пароль сервера (если есть)", prefs.getString("pass", "") ?: "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Настройки MTA")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit()
                    .putString("ip", ip.text.toString().trim())
                    .putInt("port", port.text.toString().toIntOrNull() ?: Config.DEFAULT_PORT)
                    .putString("pass", pass.text.toString())
                    .apply()
            }
            .setNeutralButton("Переустановить файлы") { _, _ ->
                gameDir.deleteRecursively()
                toast("Файлы удалены, при запуске скачаются заново")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun onPlay() {
        if (busy) return
        val name = nick.text.toString().trim()
        if (!Regex("^[A-Za-z0-9_]{3,22}$").matches(name)) {
            toast("Ник: 3–22 символа, латиница, цифры и _")
            return
        }
        prefs.edit().putString("nick", name).apply()

        if (File(gameDir, ".ok").exists()) launchGame() else download()
    }

    private fun download() {
        if (Config.ZIP_URL.isBlank()) {
            toast("Укажите ZIP_URL в Config.kt")
            return
        }
        busy = true
        progress.progress = 0
        progress.visibility = View.VISIBLE
        subtitle.text = "ЗАГРУЗКА 0%"

        Thread {
            try {
                gameDir.deleteRecursively()
                gameDir.mkdirs()
                val zip = File(getExternalFilesDir(null), "game.zip")

                val c = URL(Config.ZIP_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                val total = c.contentLengthLong
                var done = 0L
                var lastPct = -1
                c.inputStream.use { input ->
                    FileOutputStream(zip).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    ui.post {
                                        progress.progress = pct
                                        subtitle.text = "ЗАГРУЗКА $pct%"
                                    }
                                }
                            }
                        }
                    }
                }

                ui.post { subtitle.text = "РАСПАКОВКА..." }
                unzip(zip, gameDir)
                zip.delete()
                File(gameDir, ".ok").createNewFile()

                ui.post {
                    finishBusy()
                    launchGame()
                }
            } catch (e: Exception) {
                ui.post {
                    finishBusy()
                    toast("Ошибка загрузки: ${e.message}")
                }
            }
        }.start()
    }

    private fun finishBusy() {
        busy = false
        progress.visibility = View.GONE
        subtitle.text = "УЖЕ СЕЙЧАС"
    }

    private fun unzip(zip: File, dest: File) {
        val root = dest.canonicalPath + File.separator
        ZipInputStream(FileInputStream(zip)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(root)) throw IOException("Недопустимый путь в архиве")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zin.copyTo(it) }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun launchGame() {
        val pkg = Config.CLIENT_PACKAGE
        if (pkg.isBlank()) {
            toast("Укажите CLIENT_PACKAGE в Config.kt")
            return
        }

        if (!isInstalled(pkg)) {
            val apk = gameDir.walkTopDown().firstOrNull { it.isFile && it.extension.equals("apk", true) }
            if (apk == null) {
                toast("В архиве нет APK клиента")
                return
            }
            if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
                toast("Разрешите установку и нажмите ИГРАТЬ снова")
                return
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }

        val ip = prefs.getString("ip", Config.DEFAULT_IP) ?: Config.DEFAULT_IP
        val port = prefs.getInt("port", Config.DEFAULT_PORT)
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Не удалось запустить клиент")
            return
        }
        // Названия extra зависят от конкретного клиента, подставьте свои при необходимости
        intent.putExtra("nickname", prefs.getString("nick", ""))
        intent.putExtra("host", ip)
        intent.putExtra("port", port)
        intent.putExtra("password", prefs.getString("pass", ""))
        startActivity(intent)
    }
}
