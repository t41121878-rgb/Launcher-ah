1. Откройте app/src/main/java/com/mylauncher/Config.kt и впишите ZIP_URL, CLIENT_PACKAGE, IP и порт.
2. Сборка APK:
   - Android Studio: открыть папку проекта -> Build -> Build APK(s)
   - или загрузить проект на GitHub: вкладка Actions -> Build APK -> скачать launcher-apk
3. Свой шрифт: положите .ttf в app/src/main/res/font и укажите android:fontFamily в layout.
4. Иконку приложения добавьте через Android Studio: New -> Image Asset.
